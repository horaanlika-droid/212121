/* Smoke test: исполняет реальные действия store.ts */
import { useApp, level, canPost, earnedBadges, earnedItems } from '../src/lib/store';
import { AUTHORS, SECTIONS } from '../src/lib/data';

const s = () => useApp.getState();
let fail = 0;
const ok = (cond: boolean, name: string) => {
  console.log((cond ? 'PASS' : 'FAIL') + ' ' + name);
  if (!cond) fail++;
};

// sequential unlock
ok(!s().applied.includes('water'), 'start clean');
s().applySection('water');
ok(s().applied.includes('water'), 'applySection water');
ok(s().xp === 2430 + 20, 'xp +20');
ok(earnedBadges(s()).includes('badge-water'), 'badge-water earned');

// survival +10 xp
const xp0 = s().xp;
s().doSurvival('fire');
ok(s().xp === xp0 + 10, 'survival +10 xp');
ok(earnedBadges(s()).includes('badge-fire'), 'badge-fire earned');

// authors +3 karma, enlightened
const k0 = s().karma;
AUTHORS.forEach((a) => s().readAuthor(a.id));
ok(s().karma === k0 + AUTHORS.length * 3, 'authors +3 karma each');
ok(earnedBadges(s()).includes('badge-enlightened'), 'enlightened badge');

// solve problem -> item
s().solveProblem('bench');
ok(s().problems.find((p) => p.id === 'bench')!.status === 'done', 'problem done');
ok(earnedItems(s()).includes('item-wrench'), 'item-wrench earned');

// support fund -> raised bump + item-heart
const raised0 = s().funds.find((f) => f.id === 'alley')!.raised;
s().supportFund('alley');
ok(s().funds.find((f) => f.id === 'alley')!.raised === raised0 + 500, 'fund raised +500');
ok(earnedItems(s()).includes('item-heart'), 'item-heart earned');

// volunteer -> forum + map add
ok(!canPost({ volunteer: false, xp: 0 }), 'lvl1 cannot post');
ok(canPost(s()), 'volunteer/level can post');
s().becomeVolunteer();
ok(earnedBadges(s()).includes('badge-volunteer'), 'volunteer badge');
const n0 = s().problems.length;
s().addProblem({ title: 'тест', desc: 'д', icon: 't-bench', x: 50, y: 50 });
ok(s().problems.length === n0 + 1, 'addProblem on map');

// create fund from problem
const f0 = s().funds.length;
s().createFund('green', 100000);
ok(s().funds.length === f0 + 1, 'createFund');
ok(earnedItems(s()).includes('item-lamp'), 'item-lamp earned');

// admin post
s().toggleAdmin();
ok(s().isAdmin, 'admin on');
const p0 = s().posts.length;
s().addPost('тест', 'текст');
ok(s().posts.length === p0 + 1, 'addPost');

ok(SECTIONS.length === 8, '8 sections');
ok(level(2430) >= 2, 'level formula');

console.log(fail === 0 ? 'ALL PASS' : fail + ' FAILURES');
process.exit(fail === 0 ? 0 : 1);
