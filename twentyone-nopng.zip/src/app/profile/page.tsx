'use client';
import Link from 'next/link';
import Shell from '@/components/Shell';
import { Bar, Px } from '@/components/ui';
import { BADGE_NAMES, ITEM_DEFS, fmt } from '@/lib/data';
import { earnedBadges, earnedItems, level, useApp } from '@/lib/store';

export default function Profile() {
  const s = useApp();
  const badges = earnedBadges(s);
  const items = earnedItems(s);

  return (
    <Shell title="ПРОФИЛЬ">
      <div className="card p-4 flex items-center gap-4">
        <div className="relative w-[72px] h-[72px] shrink-0">
          <Px n="avatar" size={72} />
          {s.acc.cap && <span className="absolute inset-0"><Px n="acc-cap" size={72} /></span>}
          {s.acc.glasses && <span className="absolute inset-0"><Px n="acc-glasses" size={72} /></span>}
          {s.acc.flower && <span className="absolute inset-0"><Px n="acc-flower" size={72} /></span>}
        </div>
        <div className="flex-1 space-y-1">
          <div className="flex items-center gap-4 text-[12px] font-bold">
            <span className="inline-flex items-center gap-1"><Px n="ic-heart" size={14} />{fmt(s.karma)}</span>
            <span className="inline-flex items-center gap-1"><Px n="ic-star" size={14} />{fmt(s.xp)}</span>
          </div>
          <div className="flex items-center gap-2 text-[9px] font-bold">
            <span>{level(s.xp)}</span>
            <Bar value={s.xp % 100} max={100} className="flex-1" />
          </div>
          <div className="flex gap-1">
            {(['cap', 'glasses', 'flower'] as const).map((k) => (
              <button key={k} onClick={() => s.setAcc(k)}
                className={`p-1 border-2 rounded ${s.acc[k] ? 'border-ink bg-lite' : 'border-transparent'}`}>
                <Px n={'acc-' + k} size={18} />
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="card p-3 space-y-2">
        <div className="text-[10px] font-bold">ЗНАЧКИ · {badges.length}</div>
        <div className="grid grid-cols-6 gap-2">
          {Object.keys(BADGE_NAMES).map((b) => (
            <span key={b} title={BADGE_NAMES[b]} className="flex flex-col items-center">
              <Px n={b} size={34} className={badges.includes(b) ? '' : 'grayscale opacity-25'} />
            </span>
          ))}
        </div>
      </div>

      <div className="card p-3 space-y-2">
        <div className="text-[10px] font-bold">КОЛЛЕКЦИЯ · {items.length}</div>
        <div className="grid grid-cols-6 gap-2">
          {ITEM_DEFS.map((i) => (
            <span key={i.id} title={i.name} className="flex flex-col items-center">
              <Px n={i.id} size={34} className={items.includes(i.id) ? '' : 'grayscale opacity-25'} />
            </span>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {!s.volunteer ? (
          <button className="btn" disabled={level(s.xp) < 2} onClick={s.becomeVolunteer}>
            <Px n="badge-volunteer" size={16} />ВОЛОНТЁР
          </button>
        ) : (
          <span className="btn opacity-70"><Px n="badge-volunteer" size={16} />ВОЛОНТЁР</span>
        )}
        <button className="btn" onClick={s.toggleAdmin}>
          <Px n="ui-lock" size={14} />{s.isAdmin ? 'АДМИН: ВКЛ' : 'АДМИН: ВЫКЛ'}
        </button>
        <Link href="/thanks" className="btn"><Px n="ui-download" size={14} />СТИКЕР</Link>
        <button className="btn" onClick={s.reset}><Px n="ui-close" size={14} />СБРОС</button>
      </div>
      {level(s.xp) < 2 && !s.volunteer && (
        <div className="text-[8px] text-grey text-center">волонтёрство — с уровня 2</div>
      )}
    </Shell>
  );
}
