'use client';
import Link from 'next/link';
import Shell from '@/components/Shell';
import { Px } from '@/components/ui';
import { img } from '@/lib/base';

export default function Thanks() {
  return (
    <Shell title="СПАСИБО!">
      <div className="card p-6 flex items-center justify-center gap-6">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={img('sticker.png')} alt="стикер 21" className="pix w-28 h-28" />
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={img('qr.png')} alt="qr" className="pix w-24 h-24" />
      </div>
      <div className="text-center text-[10px] font-bold leading-5">
        СКАЧАЙ СТИКЕР<br />И ДЕЛИСЬ ПРИЛОЖЕНИЕМ<br />С СОСЕДЯМИ!
      </div>
      <a className="btn w-full py-3" href={img('sticker.png')} download="sticker-21.png">
        <Px n="ui-download" size={14} />СКАЧАТЬ СТИКЕР
      </a>
      <Link href="/" className="btn w-full py-3">ГОТОВО</Link>
    </Shell>
  );
}
